API_CODES = {
    "Type": {
        "P": {
                "pl": "Typ jednostki – jednostka prawna",
                "eng": "<translation_needed>"
            },
        "F": {
                "pl": "Typ jednostki – jednostka fizyczna (os. fizyczna prowadząca działalność gospodarczą)",
                "eng": "<translation_needed>"
            },
        "LP": {
                "pl": "Typ jednostki – jednostka lokalna jednostki prawnej",
                "eng": "<translation_needed>"
            },
        "LF": {
                "pl": "Typ jednostki – jednostka lokalna jednostki fizycznej",
                "eng": "<translation_needed>"
            }
    },
    "SilosID": {
        "1": {
                "pl": "Miejsce prowadzenia działalności zarejestrowanej w CEIDG (tylko typy F i LF))",
                "eng": "<translation_needed>"
            },
        "2": {
                "pl": "Miejsce prowadzenia działalności rolniczej (tylko typy F i LF))",
                "eng": "<translation_needed>"
            },
        "3": {
                "pl": "Miejsce prowadzenia działalności pozostałej (tylko typy F i LF))",
                "eng": "<translation_needed>"
            },
        "4": {
                "pl": "Miejsce prowadzenia działalności zlikwidowanej w starym systemie KRUPGN",
                "eng": "<translation_needed>"
            },
        "6": {
                "pl": "Miejsce prowadzenia działalności jednostki prawnej (tylko typy P i LP)",
                "eng": "<translation_needed>"
            }
    },
    "GetValue": {
        "0": {
                "pl": "Brak wiadomości",
                "eng": "<translation_needed>"
            },
        "1": {
                "pl": "Konieczne jest pobranie i sprawdzenie kodu Captcha (metody PobierzCaptcha i SprawdzCaptcha).",
                "eng": "<translation_needed>"
            },
        "2": {
                "pl": "Do metody DaneSzukaj przekazano zbyt wiele identyfikatorów.",
                "eng": "<translation_needed>"
            },
        "4": {
                "pl": "Nie znaleziono podmiotów.",
                "eng": "<translation_needed>"
            },
        "5": {
                "pl": "Brak uprawnień do raportu.",
                "eng": "<translation_needed>"
            },
        "7": {
                "pl": "Brak sesji. Sesja wygasła lub przekazano nieprawidłową wartość nagłówka sid.",
                "eng": "<translation_needed>"
            }
    },
    "ServiceStatus": {
        "0": {
                "pl": "Niedostępna",
                "eng": "Unavailable"
        },
        "1": {
                "pl": "Dostępna",
                "eng": "Available"
        },
        "2": {
                "pl": "Przerwa techniczna",
                "eng": "Maintenance"
        }
    }
}
