from string import digits

from .exceptions import RegonConvertionLengthError
from .exceptions import RegonConvertionTypeError

REGON_WEIGHTS = [8, 9, 2, 3, 4, 5, 6, 7]


def regon8_to_9(regon8):
    """Convert REGON8 to REGON9

    Parameters
    ----------
    regon8 : str
        REGON8

    Returns
    -------
    str
        REGON9

    Raises
    ------
    RegonConvertionTypeError
        If regon8 is not str
    RegonConvertionLengthError
        If regon8 length is not 8
    """
    if not isinstance(regon8, str):
        raise RegonConvertionTypeError(regon8)
    if len(regon8) != 8:
        raise RegonConvertionLengthError(regon8)
    # TODO: Validate regon 8 here
    a, b = list(regon8), REGON_WEIGHTS
    a = list(map(lambda x: int(x), a))
    last_digit = sum(list(map(lambda x: x[0]*x[1], zip(a, b)))) % 11
    regon9 = "{regon8}{last_digit}".format(
        regon8=regon8,
        last_digit=last_digit)
    return regon9
