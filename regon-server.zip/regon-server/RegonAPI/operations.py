"""
    Extends RegonAPI with operations
"""
from RegonAPI.parsers import parse_xml_response
from RegonAPI.settings import REPORTS
from RegonAPI.exceptions import ApiUnknownReportNameError


class RegonAPIOperations(object):
    # TODO: docs
    def searchData(
        self,
        krs=None,
        regon=None,
        nip=None,
        regons9=None,
        regons14=None,
        krss=None,
        nips=None
    ):
        # TODO: docs
        # TODO: tests
        search_param = "pParametryWyszukiwania"
        request_data = {search_param: {}}
        map_ = {
            "krs": "Krs",
            "regon": "Regon",
            "nip": "Nip",
            "regons9": "Regony9zn",
            "regons14": "Regony14zn",
            "krss": "Krsy",
            "nips": "Nipy"
        }
        for k, v in locals().items():
            if k in map_.keys():
                if v is not None:
                    request_data[search_param][map_[k]] = v
        response = self.service.DaneSzukaj(**request_data)
        return parse_xml_response(response) if response else None

    def dataDownloadFullReport(self, regon, report_name, strict=True):
        if strict and report_name not in REPORTS:
            raise ApiUnknownReportNameError(report_name)
        request_data = {
            "pRegon": regon,
            "pNazwaRaportu": report_name
        }
        response = self.service.DanePobierzPelnyRaport(**request_data)
        return parse_xml_response(response) if response else None
