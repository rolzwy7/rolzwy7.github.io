"""
    Test data
"""

from RegonAPI import api_codes_json

SERVICE_DOMAIN = 'https://wyszukiwarkaregontest.stat.gov.pl'

WSDL = "{service_domain}/wsBIR/wsdl/UslugaBIRzewnPubl.xsd".format(
    service_domain=SERVICE_DOMAIN)


URL = '{service_domain}/wsBIR/UslugaBIRzewnPubl.svc'.format(
    service_domain=SERVICE_DOMAIN)

CODES = api_codes_json.API_CODES

KEY = 'abcde12345abcde12345'  # Regon API official test key

SID = '3xg5b1m7nuoeye55h667'  # example sid

SERVICE_NAMESPACE = '{http://tempuri.org/}e3'

# Test numbers
KRS = '0000006865'  # exiting krs
NIP = '7342867148'  # exiting nip
REGON9 = '492707333'  # exiting regon9
REGON8 = '49270733'  # exiting regon8

# Available operations
available_operations = [
    "PobierzCaptcha",
    "SprawdzCaptcha",
    "GetValue",
    "SetValue",
    "Zaloguj",
    "Wyloguj",
    "DaneSzukaj",
    "DanePobierzPelnyRaport",
    "DaneKomunikat",
]
