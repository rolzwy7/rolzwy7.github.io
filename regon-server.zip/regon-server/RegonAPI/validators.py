import re

from RegonAPI.converters import regon8_to_9


def _re_is_digit_string(str_, str_len):
    """Digit string validation

    Parameters
    ----------
    str_ : str
        Digit string to validate
    str_len : int
        Digit string length

    Returns
    -------
    bool
        True if valid, False otherwise

    Raises
    ------
    TypeError
        If str_ is not str type
    TypeError
        If str_len is not int type
    """
    regex = "^[0-9]{%s}$" % str_len
    if not isinstance(str_, str):
        raise TypeError("_re_is_digit_string - str_ is not str")
    if not isinstance(str_len, int):
        raise TypeError("_re_is_digit_string - str_len is not int")
    ret = re.match(regex, str_)
    return True if ret is not None else False


def is_valid_regon8(regon8):
    """Regon8 validation

    Parameters
    ----------
    regon8 : str
        REGON8

    Returns
    -------
    bool
        True if valid, False otherwise

    Raises
    ------
    TypeError
        If regon8 is not str type
    """
    ret = _re_is_digit_string(regon8, 8)
    return True if ret else False


def is_valid_regon9(regon9):
    """Regon9 validation

    Parameters
    ----------
    regon9 : str
        REGON9

    Returns
    -------
    bool
        True if valid, False otherwise

    Raises
    ------
    TypeError
        If regon9 is not str type
    """
    if not _re_is_digit_string(regon9, 9):
        return False
    regon8 = regon9[:8]
    return regon8_to_9(regon8) == regon9
