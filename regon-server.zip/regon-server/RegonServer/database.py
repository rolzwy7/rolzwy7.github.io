import MySQLdb

from _mysql_exceptions import IntegrityError

from RegonServer.utils import woj_to_teryt
from RegonServer import settings


class DB(object):

    db = None
    cursor = None

    def __init__(self):
        pass

    @staticmethod
    def connect():
        if DB.db is None:
            DB.db = MySQLdb.connect(
                host=settings.db_host,
                port=settings.db_port,
                user=settings.db_user,
                passwd=settings.db_passwd,
                db=settings.db_name,
                charset="utf8mb4",
                init_command='SET NAMES utf8mb4'
            )
            DB.cursor = DB.db.cursor()

    def get_sample_jp(self):
        result = DB.cursor.execute("SELECT * FROM jednostki_prawne LIMIT 10")

    def krs_in(self, krs):
        res = DB.cursor.execute("""
            SELECT COUNT(krs) as 'res'
            FROM jednostki_prawne
            WHERE krs = {krs}
        """.format(krs=krs))
        ret = DB.cursor.fetchone()
        return True if ret[0] == 1 else False

    def insert_typ_jednostki(self, krs, data):
        try:
            DB.cursor.executemany(
                """INSERT INTO jednostki_prawne
                VALUES (0, %s, %s, %s, %s, %s, %s, %s)""",
                [(
                    krs,
                    data.get("Regon", "").encode("utf8"),
                    data.get("Nazwa", "").encode("utf8"),
                    woj_to_teryt(data.get("Wojewodztwo", "")).encode("utf8"),
                    data.get("Miejscowosc", "").encode("utf8"),
                    data.get("Ulica", "").encode("utf8"),
                    data.get("KodPocztowy", "").encode("utf8")
                  )]
            )
            DB.db.commit()
        except IntegrityError as e:
            DB.db.rollback()
        except Exception as e:
            raise

    def insert_publ_dane_raport_prawna(self, krs, data):
        try:
            DB.cursor.execute(
                """INSERT INTO publ_dane_raport_prawna
                VALUES (0,
                    '{krs}',
                    '{praw_adKorGmina_Nazwa}',
                    '{praw_adKorGmina_Symbol}',
                    '{praw_adKorKodPocztowy}',
                    '{praw_adKorKraj_Nazwa}',
                    '{praw_adKorKraj_Symbol}',
                    '{praw_adKorMiejscowoscPoczty_Nazwa}',
                    '{praw_adKorMiejscowosc_Nazwa}',
                    '{praw_adKorMiejscowosc_Symbol}',
                    '{praw_adKorMiejscowosciPoczty_Symbol}',
                    '{praw_adKorNazwaPodmiotuDoKorespondencji}',
                    '{praw_adKorNietypoweMiejsceLokalizacji}',
                    '{praw_adKorNumerLokalu}',
                    '{praw_adKorNumerNieruchomosci}',
                    '{praw_adKorPowiat_Nazwa}',
                    '{praw_adKorPowiat_Symbol}',
                    '{praw_adKorUlica_Nazwa}',
                    '{praw_adKorUlica_Symbol}',
                    '{praw_adKorWojewodztwo_Nazwa}',
                    '{praw_adKorWojewodztwo_Symbol}',
                    '{praw_adSiedzGmina_Nazwa}',
                    '{praw_adSiedzGmina_Symbol}',
                    '{praw_adSiedzKodPocztowy}',
                    '{praw_adSiedzKraj_Nazwa}',
                    '{praw_adSiedzKraj_Symbol}',
                    '{praw_adSiedzMiejscowoscPoczty_Nazwa}',
                    '{praw_adSiedzMiejscowoscPoczty_Symbol}',
                    '{praw_adSiedzMiejscowosc_Nazwa}',
                    '{praw_adSiedzMiejscowosc_Symbol}',
                    '{praw_adSiedzNietypoweMiejsceLokalizacji}',
                    '{praw_adSiedzNumerLokalu}',
                    '{praw_adSiedzNumerNieruchomosci}',
                    '{praw_adSiedzPowiat_Nazwa}',
                    '{praw_adSiedzPowiat_Symbol}',
                    '{praw_adSiedzUlica_Nazwa}',
                    '{praw_adSiedzUlica_Symbol}',
                    '{praw_adSiedzWojewodztwo_Nazwa}',
                    '{praw_adSiedzWojewodztwo_Symbol}',
                    '{praw_adresEmail}',
                    '{praw_adresEmail2}',
                    '{praw_adresStronyinternetowej}',
                    '{praw_dataPowstania}',
                    '{praw_dataRozpoczeciaDzialalnosci}',
                    '{praw_dataSkresleniazRegon}',
                    '{praw_dataWpisuDoREGON}',
                    '{praw_dataWpisuDoRejestruEwidencji}',
                    '{praw_dataWznowieniaDzialalnosci}',
                    '{praw_dataZaistnieniaZmiany}',
                    '{praw_dataZakonczeniaDzialalnosci}',
                    '{praw_dataZawieszeniaDzialalnosci}',
                    '{praw_formaFinansowania_Nazwa}',
                    '{praw_formaFinansowania_Symbol}',
                    '{praw_formaWlasnosci_Nazwa}',
                    '{praw_formaWlasnosci_Symbol}',
                    '{praw_jednostekLokalnych}',
                    '{praw_nazwa}',
                    '{praw_nazwaSkrocona}',
                    '{praw_nip}',
                    '{praw_numerFaksu}',
                    '{praw_numerTelefonu}',
                    '{praw_numerWewnetrznyTelefonu}',
                    '{praw_numerWrejestrzeEwidencji}',
                    '{praw_organRejestrowy_Nazwa}',
                    '{praw_organRejestrowy_Symbol}',
                    '{praw_organZalozycielski_Nazwa}',
                    '{praw_organZalozycielski_Symbol}',
                    '{praw_podstawowaFormaPrawna_Nazwa}',
                    '{praw_podstawowaFormaPrawna_Symbol}',
                    '{praw_regon14}',
                    '{praw_rodzajRejestruEwidencji_Nazwa}',
                    '{praw_rodzajRejestruEwidencji_Symbol}',
                    '{praw_szczegolnaFormaPrawna_Nazwa}',
                    '{praw_szczegolnaFormaPrawna_Symbol}'
                )
                """.format(krs=krs, **data)
            )
            DB.db.commit()
        except IntegrityError as e:
            DB.db.rollback()
        except Exception as e:
            raise

    def insert_publ_dane_raport_dzialalnosci_prawnej(self, krs, data):
        try:
            DB.cursor.execute(
                """INSERT INTO publ_dane_raport_dzialalnosci_prawnej
                VALUES (0,
                    '{krs}',
                    '{praw_pkdKod}',
                    '{praw_pkdNazwa}',
                    '{praw_pkdPrzewazajace}'
                )
                """.format(krs=krs, **data)
            )
            DB.db.commit()
        except IntegrityError as e:
            DB.db.rollback()
        except Exception as e:
            raise
