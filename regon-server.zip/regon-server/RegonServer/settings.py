MAX_KRS = 750000


db_name = 'regon_db'
db_host = 'localhost'
db_user = 'regon_server_user'
db_passwd = 'Ag545#$f??/f6gt'
db_port = 3306
