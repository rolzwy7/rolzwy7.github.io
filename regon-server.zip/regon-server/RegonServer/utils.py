import random

from RegonServer.settings import MAX_KRS


def get_random_krs():
    str_ = str(random.randint(0, MAX_KRS))
    return (10 - len(str_)) * '0' + str_
    # database check


def woj_to_teryt(woj):
    ret = {
        'DOLNOŚLĄSKIE': '02',
        'KUJAWSKO-POMORSKIE': '04',
        'LUBELSKIE': '06',
        'LUBUSKIE': '08',
        'ŁÓDZKIE': '10',
        'MAŁOPOLSKIE': '12',
        'MAZOWIECKIE': '14',
        'OPOLSKIE': '16',
        'PODKARPACKIE': '18',
        'PODLASKIE': '20',
        'POMORSKIE': '22',
        'ŚLĄSKIE': '24',
        'ŚWIĘTOKRZYSKIE': '26',
        'WARMIŃSKO-MAZURSKIE': '28',
        'WIELKOPOLSKIE': '30',
        'ZACHODNIOPOMORSKIE': '32'}
    return ret.get(woj, "00")
