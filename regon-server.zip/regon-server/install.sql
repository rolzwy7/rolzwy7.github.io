DROP DATABASE IF EXISTS regon_db;
CREATE DATABASE IF NOT EXISTS regon_db DEFAULT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_polish_ci';
USE regon_db;

GRANT ALL PRIVILEGES ON regon_db.* TO ''@'' IDENTIFIED BY 'Ag545#$f??/f6gt';


CREATE TABLE wojewodztwa(
  `id` int not null primary key auto_increment,
  `teryt` char(2) not null unique,
  `wojewodztwo` varchar(32) not null unique
) ENGINE=InnoDB;

INSERT INTO `wojewodztwa` VALUES (0, '02', 'DOLNOŚLĄSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '04', 'KUJAWSKO-POMORSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '06', 'LUBELSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '08', 'LUBUSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '10', 'ŁÓDZKIE');
INSERT INTO `wojewodztwa` VALUES (0, '12', 'MAŁOPOLSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '14', 'MAZOWIECKIE');
INSERT INTO `wojewodztwa` VALUES (0, '16', 'OPOLSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '18', 'PODKARPACKIE');
INSERT INTO `wojewodztwa` VALUES (0, '20', 'PODLASKIE');
INSERT INTO `wojewodztwa` VALUES (0, '22', 'POMORSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '24', 'ŚLĄSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '26', 'ŚWIĘTOKRZYSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '28', 'WARMIŃSKO-MAZURSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '30', 'WIELKOPOLSKIE');
INSERT INTO `wojewodztwa` VALUES (0, '32', 'ZACHODNIOPOMORSKIE');


CREATE TABLE jednostki_prawne(
  `id` int not null primary key auto_increment,
  `krs` char(10) not null unique,
  `regon` varchar(14) not null,
  `nazwa` varchar(256) not null,
  `wojewodztwo` varchar(32) not null,
  `miejscowosc` varchar(64) not null,
  `ulica` varchar(64) not null,
  `kod_pocztowy` char(6) not null
) ENGINE=InnoDB;

CREATE INDEX `krs_index` ON `jednostki_prawne`(`krs`);



CREATE TABLE publ_dane_raport_prawna(
  `id` int not null primary key auto_increment,
  `krs` varchar(10) unique,
  `praw_adKorGmina_Nazwa` varchar(256),
  `praw_adKorGmina_Symbol` varchar(128),
  `praw_adKorKodPocztowy` varchar(128),
  `praw_adKorKraj_Nazwa` varchar(256),
  `praw_adKorKraj_Symbol` varchar(128),
  `praw_adKorMiejscowoscPoczty_Nazwa` varchar(256),
  `praw_adKorMiejscowosc_Nazwa` varchar(256),
  `praw_adKorMiejscowosc_Symbol` varchar(128),
  `praw_adKorMiejscowosciPoczty_Symbol` varchar(128),
  `praw_adKorNazwaPodmiotuDoKorespondencji` varchar(128),
  `praw_adKorNietypoweMiejsceLokalizacji` varchar(128),
  `praw_adKorNumerLokalu` varchar(128),
  `praw_adKorNumerNieruchomosci` varchar(128),
  `praw_adKorPowiat_Nazwa` varchar(256),
  `praw_adKorPowiat_Symbol` varchar(128),
  `praw_adKorUlica_Nazwa` varchar(256),
  `praw_adKorUlica_Symbol` varchar(128),
  `praw_adKorWojewodztwo_Nazwa` varchar(256),
  `praw_adKorWojewodztwo_Symbol` varchar(128),
  `praw_adSiedzGmina_Nazwa` varchar(256),
  `praw_adSiedzGmina_Symbol` varchar(128),
  `praw_adSiedzKodPocztowy` varchar(128),
  `praw_adSiedzKraj_Nazwa` varchar(256),
  `praw_adSiedzKraj_Symbol` varchar(128),
  `praw_adSiedzMiejscowoscPoczty_Nazwa` varchar(256),
  `praw_adSiedzMiejscowoscPoczty_Symbol` varchar(128),
  `praw_adSiedzMiejscowosc_Nazwa` varchar(256),
  `praw_adSiedzMiejscowosc_Symbol` varchar(128),
  `praw_adSiedzNietypoweMiejsceLokalizacji` varchar(128),
  `praw_adSiedzNumerLokalu` varchar(128),
  `praw_adSiedzNumerNieruchomosci` varchar(128),
  `praw_adSiedzPowiat_Nazwa` varchar(256),
  `praw_adSiedzPowiat_Symbol` varchar(128),
  `praw_adSiedzUlica_Nazwa` varchar(256),
  `praw_adSiedzUlica_Symbol` varchar(128),
  `praw_adSiedzWojewodztwo_Nazwa` varchar(256),
  `praw_adSiedzWojewodztwo_Symbol` varchar(128),
  `praw_adresEmail` varchar(128),
  `praw_adresEmail2` varchar(128),
  `praw_adresStronyinternetowej` varchar(128),
  `praw_dataPowstania` varchar(128),
  `praw_dataRozpoczeciaDzialalnosci` varchar(128),
  `praw_dataSkresleniazRegon` varchar(128),
  `praw_dataWpisuDoREGON` varchar(128),
  `praw_dataWpisuDoRejestruEwidencji` varchar(128),
  `praw_dataWznowieniaDzialalnosci` varchar(128),
  `praw_dataZaistnieniaZmiany` varchar(128),
  `praw_dataZakonczeniaDzialalnosci` varchar(128),
  `praw_dataZawieszeniaDzialalnosci` varchar(128),
  `praw_formaFinansowania_Nazwa` varchar(256),
  `praw_formaFinansowania_Symbol` varchar(128),
  `praw_formaWlasnosci_Nazwa` varchar(256),
  `praw_formaWlasnosci_Symbol` varchar(128),
  `praw_jednostekLokalnych` varchar(128),
  `praw_nazwa` varchar(128),
  `praw_nazwaSkrocona` varchar(128),
  `praw_nip` varchar(128),
  `praw_numerFaksu` varchar(128),
  `praw_numerTelefonu` varchar(128),
  `praw_numerWewnetrznyTelefonu` varchar(128),
  `praw_numerWrejestrzeEwidencji` varchar(128),
  `praw_organRejestrowy_Nazwa` varchar(256),
  `praw_organRejestrowy_Symbol` varchar(128),
  `praw_organZalozycielski_Nazwa` varchar(256),
  `praw_organZalozycielski_Symbol` varchar(128),
  `praw_podstawowaFormaPrawna_Nazwa` varchar(256),
  `praw_podstawowaFormaPrawna_Symbol` varchar(128),
  `praw_regon14` char(128),
  `praw_rodzajRejestruEwidencji_Nazwa` varchar(256),
  `praw_rodzajRejestruEwidencji_Symbol` varchar(128),
  `praw_szczegolnaFormaPrawna_Nazwa` varchar(256),
  `praw_szczegolnaFormaPrawna_Symbol` varchar(128)
) ENGINE=InnoDB;

CREATE INDEX `publ_dane_krs_index` ON `publ_dane_raport_prawna`(`krs`);


CREATE TABLE publ_dane_raport_dzialalnosci_prawnej(
  `id` int not null primary key auto_increment,
  `krs` char(10) not null unique,
  `praw_pkdKod` varchar(16) not null,
  `praw_pkdNazwa` varchar(128) not null,
  `praw_pkdPrzewazajace` varchar(16) not null
) ENGINE=InnoDB;

CREATE INDEX `publ_dane_raport_dzialalnosci_prawnej_index` ON `publ_dane_raport_dzialalnosci_prawnej`(`krs`);
