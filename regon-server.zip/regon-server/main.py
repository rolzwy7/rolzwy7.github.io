import time
import random
from pprint import pprint

from RegonServer.database import DB
from RegonAPI import RegonAPI
from RegonAPI.exceptions import ApiAuthenticationError
from RegonServer.utils import get_random_krs


REPORTS = [
    "PublDaneRaportFizycznaOsoba",
    "PublDaneRaportDzialalnoscFizycznejCeidg",
    "PublDaneRaportDzialalnoscFizycznejRolnicza",
    "PublDaneRaportDzialalnoscFizycznejPozostala",
    "PublDaneRaportDzialalnoscFizycznejWKrupgn",
    "PublDaneRaportLokalneFizycznej",
    "PublDaneRaportLokalnaFizycznej",
    "PublDaneRaportDzialalnosciFizycznej",
    "PublDaneRaportDzialalnosciLokalnejFizycznej",
    "PublDaneRaportPrawna",
    "PublDaneRaportDzialalnosciPrawnej",
    "PublDaneRaportLokalnePrawnej",
    "PublDaneRaportLokalnaPrawnej",
    "PublDaneRaportDzialalnosciLokalnejPrawnej",
    "PublDaneRaportWspolnicyPrawnej",
    "PublDaneRaportTypJednostki"
]


db = DB()
db.connect()

service_wsdl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/wsdl/UslugaBIRzewnPubl.xsd'

# service_url = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc'
# service_key = 'abcde12345abcde12345'

service_url = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc'
service_key = 'f8563ffea30641a1958a'

# ----------------------------------------------------------
api = RegonAPI(service_wsdl, service_url)
service_status, msg = api.get_service_status()
print(msg)
while True:
    if service_status == '1':
        break
    else:
        time.sleep(900)

try:
    api.authenticate(service_key)
except ApiAuthenticationError as e:
    print(e)
    exit(1)
# ----------------------------------------------------------


# PublDaneRaportPrawna (big)
# PublDaneRaportDzialalnosciPrawnej (big)

# for _ in REPORTS:
#     print(32*'-', _, 32*'-')
#     pprint(api.dataDownloadFullReport("492707333", _))
#
# exit(0)

TIME_STARTED = time.time()
while True:
    if abs(time.time() - TIME_STARTED) >= 1800:  # re-auth
        TIME_STARTED = time.time() - 1
        api.authenticate(service_key)

    rand_krs = get_random_krs()
    if db.krs_in(rand_krs):
        continue
    time.sleep(.25)  # debug
    search_res = api.searchData(krs=rand_krs)
    SEARCH_FOUND = False

    if search_res is not None:
        print(rand_krs, "- found")
        SEARCH_FOUND = True
        try:
            db.insert_typ_jednostki(rand_krs, search_res[0])
        except Exception as e:
            print("[!] EXCEPTION:", e)
    else:
        print(rand_krs, "- not found")

    if SEARCH_FOUND:
        # PublDaneRaportPrawna
        pdrp = api.dataDownloadFullReport(
            search_res[0]["Regon"],
            "PublDaneRaportPrawna")
        if pdrp is not None:
            try:
                db.insert_publ_dane_raport_prawna(
                    rand_krs,
                    pdrp[0]
                )
            except Exception as e:
                raise
        # PublDaneRaportDzialalnosciPrawnej
        pdrdp = api.dataDownloadFullReport(
            search_res[0]["Regon"],
            "PublDaneRaportDzialalnosciPrawnej")
        if pdrp is not None:
            try:
                db.insert_publ_dane_raport_dzialalnosci_prawnej(
                    rand_krs,
                    pdrdp[0]
                )
            except Exception as e:
                raise
