from unittest import mock

import pytest

import RegonAPI.testing as testing
import RegonAPI


@pytest.fixture
@mock.patch('RegonAPI.Client', autospec=True)
def api_mock(mockClient):
    def fin():
        pass
    api = RegonAPI.RegonAPI(testing.WSDL, testing.URL)
    return api
