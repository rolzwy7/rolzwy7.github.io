from RegonAPI.exceptions import ApiCodeTranslationError
from RegonAPI.api_codes import t
from RegonAPI.api_codes_json import API_CODES
from RegonAPI.settings import available_languages


def test_t():
    for method, method_val in API_CODES.items():
        testing_method = method
        for code in method_val.keys():
            try:
                # for settings.lang
                ret = t(method, code)
                assert isinstance(ret, str) or isinstance(ret, dict)
                # for forced lang
                for lang in available_languages:
                    ret = t(method, code, force_lang=lang)
                    assert isinstance(ret, str)
                assert True
            except Exception as e:
                assert False
    try:
        t("GetValue", "4")  # correct
        assert True
    except Exception:
        assert False

    try:
        t("GetValue", "4", force_lang="testing")  # invalid language
        assert False
    except ApiCodeTranslationError:
        assert True

    try:
        t("GetValue", "testing")  # invalid code
        assert False
    except ApiCodeTranslationError:
        assert True

    try:
        t("testing", "testing")  # invalid method & code
        assert False
    except ApiCodeTranslationError:
        assert True
