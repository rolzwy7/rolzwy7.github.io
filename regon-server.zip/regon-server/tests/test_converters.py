from RegonAPI import converters
import RegonAPI.testing as testing
from RegonAPI import exceptions


def test_regon8_to_9():
    assert converters.regon8_to_9(testing.REGON8) == testing.REGON9
    try:
        converters.regon8_to_9(12345)
        assert False
    except exceptions.RegonConvertionTypeError as e:
        assert True
    try:
        converters.regon8_to_9("123")
        assert False
    except exceptions.RegonConvertionLengthError as e:
        assert True
