from RegonAPI import parsers

from RegonAPI.testing.parsers import test_correct_response
from RegonAPI.testing.parsers import test_incorrect_responses


def test_parse_xml_response():
    result = parsers.parse_xml_response(test_correct_response)
    assert result[0]["test_param_1"] == "val1"
    assert result[0]["test_param_2"] == "val2"
    assert result[0]["test_param_3"] == "val3"
    assert result[1]["test_param_1"] == "val4"
    assert result[1]["test_param_2"] == "val5"
    assert result[1]["test_param_3"] == "val6"

    try:
        parsers.parse_xml_response(None)
        assert False
    except TypeError:
        assert True

    for _ in test_incorrect_responses:
        try:
            parsers.parse_xml_response(_)
            assert False
        except Exception as e:
            assert True
