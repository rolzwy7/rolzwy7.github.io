from tests.common import api_mock


def test_regon_api_init(api_mock):
    assert isinstance(api_mock.service_namespace, str)
    assert isinstance(api_mock.wsdl, str)
    assert isinstance(api_mock.service_url, str)
    assert api_mock.service is not None
    assert api_mock.key is None
    assert api_mock.sid is None
    api_mock.client.create_service.assert_called_once()
    api_mock.client.create_service.assert_called_once_with(
        api_mock.service_namespace,
        api_mock.service_url
    )


def test_regon_api_magic_str(api_mock):
    api_mock.service.GetValue.return_value = '2000-10-10'
    try:
        str_ = str(api_mock)
        assert True
    except Exception as e:
        assert False
    assert isinstance(str_, str)
    assert str_ != ''
    api_mock.service.GetValue.assert_called_once()
    api_mock.service.GetValue.assert_called_with(
        pNazwaParametru='StanDanych')
