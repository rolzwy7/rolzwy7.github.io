from unittest import mock

from RegonAPI import exceptions
import RegonAPI.testing as testing
import RegonAPI
from tests.common import api_mock


@mock.patch('RegonAPI.Client')
@mock.patch('RegonAPI.Session')
@mock.patch('RegonAPI.RegonAPI._check_session')
@mock.patch('RegonAPI.RegonAPI._create_service')
def test_regon_api_auth_success(
    mocked_create_service, mocked_check_session, mocked_Client,
    mocked_Session, api_mock
):
    api_mock.service.Zaloguj.return_value = testing.SID
    mocked_check_session.return_value = True

    try:
        returned = api_mock.authenticate(testing.KEY, verify=True)
        assert True
    except exceptions.ApiAuthenticationError as e:
        assert False

    api_mock.service.Zaloguj.assert_called_once()
    api_mock.service.Zaloguj.assert_called_with(testing.KEY)

    mocked_Session.assert_called_once()

    mocked_Client.assert_called_once()

    mocked_create_service.assert_called_once()

    assert api_mock.key == testing.KEY
    assert api_mock.sid == testing.SID
    assert returned == testing.SID


@mock.patch('RegonAPI.Client')
@mock.patch('RegonAPI.Session')
@mock.patch('RegonAPI.RegonAPI._check_session')
@mock.patch('RegonAPI.RegonAPI._create_service')
def test_regon_api_auth_failure(
    mocked_create_service, mocked_check_session, mocked_Client,
    mocked_Session, api_mock
):
    api_mock.service.Zaloguj.return_value = ''
    mocked_check_session.return_value = False
    try:
        api_mock.authenticate(testing.KEY, verify=True)
        assert False
    except exceptions.ApiAuthenticationError as e:
        assert True
