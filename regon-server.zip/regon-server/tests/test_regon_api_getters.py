from tests.common import api_mock
from RegonAPI.exceptions import ApiCodeTranslationError


def test_regon_api_get_last_code(api_mock):
    # Test correct return
    api_mock.service.GetValue.return_value = '4'
    code, msg = api_mock.get_last_code()
    api_mock.service.GetValue.assert_called_once()
    api_mock.service.GetValue.assert_called_with(
        pNazwaParametru='KomunikatKod')
    assert code == '4'
    assert isinstance(msg, str) or isinstance(msg, dict)
    # Test incorrect return
    api_mock.service.GetValue.reset_mock()
    try:
        api_mock.service.GetValue.return_value = 'testing'
        code, msg = api_mock.get_last_code()
        assert False
    except ApiCodeTranslationError as e:
        assert True
        api_mock.service.GetValue.assert_called_once()
        api_mock.service.GetValue.assert_called_with(
            pNazwaParametru='KomunikatKod')


def test_regon_api_get_data_status(api_mock):
    # Test correct return
    api_mock.service.GetValue.return_value = '2000-10-10'
    response = api_mock.get_data_status()
    api_mock.service.GetValue.assert_called_once()
    api_mock.service.GetValue.assert_called_with(
        pNazwaParametru='StanDanych')
    assert isinstance(response, str)
    assert response == '2000-10-10'


def test_regon_api_get_service_status(api_mock):
    # Test correct return
    api_mock.service.GetValue.return_value = '1'
    code, msg = api_mock.get_service_status()
    api_mock.service.GetValue.assert_called_once()
    api_mock.service.GetValue.assert_called_with(
        pNazwaParametru='StatusUslugi')
    assert code == '1'
    assert isinstance(msg, str) or isinstance(msg, dict)
    # Test incorrect return
    api_mock.service.GetValue.reset_mock()
    try:
        api_mock.service.GetValue.return_value = 'testing'
        code, msg = api_mock.get_service_status()
        assert False
    except ApiCodeTranslationError as e:
        assert True
        api_mock.service.GetValue.assert_called_once()
        api_mock.service.GetValue.assert_called_with(
            pNazwaParametru='StatusUslugi')


def test_regon_api_get_operations(api_mock):
    api_mock.service._operations = {"a": 1, "b": 2, "c": 3}
    operations = api_mock.get_operations()
    assert operations == ["a", "b", "c"]

    api_mock.service._operations = {}
    operations = api_mock.get_operations()
    assert operations == []

    api_mock.service._operations = None
    try:
        operations = api_mock.get_operations()
        assert False
    except AttributeError:
        assert True
