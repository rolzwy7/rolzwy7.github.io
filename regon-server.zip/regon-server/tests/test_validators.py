from RegonAPI import validators
import RegonAPI.testing as testing


def test_re_is_digit_string():
    assert validators._re_is_digit_string("12345", 5)
    assert not validators._re_is_digit_string("12345", 15)
    assert not validators._re_is_digit_string("123abc", 3)
    assert not validators._re_is_digit_string("abc123", 3)
    assert not validators._re_is_digit_string("abc123def", 3)
    assert not validators._re_is_digit_string("abc", 3)
    try:
        validators._re_is_digit_string(12345, 5)
        assert False
    except TypeError as e:
        assert True
    try:
        validators._re_is_digit_string("12345", "5")
        assert False
    except TypeError as e:
        assert True


def test_is_valid_regon8():
    assert validators.is_valid_regon8("12345678")
    assert not validators.is_valid_regon8("123")
    try:
        validators.is_valid_regon8(123)
        assert False
    except TypeError as e:
        assert True


def test_is_valid_regon9():
    assert validators.is_valid_regon9(testing.REGON9)
    assert not validators.is_valid_regon9("492707339")  # invalid regon
    assert not validators.is_valid_regon9("123")
    try:
        validators.is_valid_regon9(123)
        assert False
    except TypeError as e:
        assert True
